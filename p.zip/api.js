// getip.js
const os = require('os');
const http = require('http');
const https = require('https');

console.log('=== INFORMASI IP VPS ===\n');

// 1. IP Lokal (LAN)
const networkInterfaces = os.networkInterfaces();
console.log('📡 IP Lokal (LAN):');
Object.keys(networkInterfaces).forEach(interfaceName => {
  networkInterfaces[interfaceName].forEach(details => {
    if (details.family === 'IPv4' && !details.internal) {
      console.log(`   ${interfaceName}: ${details.address}`);
    }
  });
});

// 2. IP Publik (WAN) - Pake API eksternal
console.log('\n🌐 IP Publik (WAN):');

// Fungsi get public IP dari berbagai API
function getPublicIP() {
  const apis = [
    { host: 'api.ipify.org', path: '/' },
    { host: 'icanhazip.com', path: '/' },
    { host: 'ipapi.co', path: '/ip' },
    { host: 'ifconfig.me', path: '/ip' }
  ];

  let completed = 0;
  
  apis.forEach(api => {
    const options = {
      hostname: api.host,
      port: 80,
      path: api.path,
      method: 'GET',
      timeout: 3000
    };

    const req = http.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        console.log(`   ${api.host}: ${data.trim()}`);
        completed++;
        if (completed === apis.length) {
          console.log('\n✅ Selesai!');
        }
      });
    });

    req.on('error', (e) => {
      console.log(`   ${api.host}: Gagal (${e.message})`);
      completed++;
      if (completed === apis.length) {
        console.log('\n✅ Selesai!');
      }
    });

    req.setTimeout(3000, () => {
      req.destroy();
      console.log(`   ${api.host}: Timeout`);
      completed++;
      if (completed === apis.length) {
        console.log('\n✅ Selesai!');
      }
    });

    req.end();
  });
}

getPublicIP();